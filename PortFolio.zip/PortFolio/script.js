const phrases = [
  "Building intelligent systems to solve real-world problems",
  "Designing secure and scalable full-stack applications",
  "Exploring AI, cybersecurity, and impactful software engineering",
];

const typingNode = document.getElementById("typing");
const themeToggle = document.getElementById("theme-toggle");
const yearNode = document.getElementById("year");

let phraseIndex = 0;
let charIndex = 0;
let deleting = false;

function runTyping() {
  const current = phrases[phraseIndex];
  const speed = deleting ? 45 : 75;

  typingNode.textContent = current.slice(0, charIndex);

  if (!deleting && charIndex < current.length) {
    charIndex += 1;
  } else if (deleting && charIndex > 0) {
    charIndex -= 1;
  } else if (!deleting && charIndex === current.length) {
    deleting = true;
    setTimeout(runTyping, 1300);
    return;
  } else {
    deleting = false;
    phraseIndex = (phraseIndex + 1) % phrases.length;
  }

  setTimeout(runTyping, speed);
}

function setupReveals() {
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("in-view");
        }
      });
    },
    { threshold: 0.15 }
  );

  document.querySelectorAll(".reveal").forEach((element) => {
    observer.observe(element);
  });
}

function setupTheme() {
  const stored = localStorage.getItem("portfolio-theme");
  if (stored === "light") {
    document.body.classList.add("light");
    themeToggle.textContent = "☀️";
  } else {
    themeToggle.textContent = "🌙";
  }

  themeToggle.addEventListener("click", () => {
    document.body.classList.toggle("light");
    const isLight = document.body.classList.contains("light");
    themeToggle.textContent = isLight ? "☀️" : "🌙";
    localStorage.setItem("portfolio-theme", isLight ? "light" : "dark");
  });
}

function init() {
  if (typingNode) runTyping();
  setupReveals();
  setupTheme();
  if (yearNode) yearNode.textContent = new Date().getFullYear();
}

init();
